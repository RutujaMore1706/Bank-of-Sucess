﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Business;
using BOS1.Account.Entities;

namespace BOS1.Account.view
{
    class AccountForm
    {
        
        public void OpenAccount()
        {
            //Collect Data from User
            IAccount account = AccountFactory.Create("Savings");
            account.Name = "Rutuja";
            account.Pin = 1234;
            account.Privilege = Privilege.GOLD;
            account.Isactive = false;

            //AccountManager manager = new AccountManager();
            IAccountManager manager = AccountManagerFactory.Create();
            manager.Open(account, "Savings");

        }

        public void CloseAccount()
        {
            //Collect Data from User
            IAccount account = AccountFactory.Create("Savings");
            account.Name = "Satish";
            account.Pin = 1234;
            account.Privilege = Privilege.GOLD;
            account.Isactive = false;

            //AccountManager manager = new AccountManager();
            IAccountManager manager = AccountManagerFactory.Create();
            try
            {
                manager.Close(account);
            }
               
            catch (AccountAlreadyClosedException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }

        public void Withdraw()
        {
            //Collect Data from User
            IAccount account = AccountFactory.Create("Savings");
            account.Name = "Rutuja";
            account.Pin = 1234;
            account.Privilege = Privilege.GOLD;
            account.Isactive = true;
            account.Balance = 50000.00;

            //AccountManager manager = new AccountManager();
            IAccountManager manager = AccountManagerFactory.Create();
            try
            {
                manager.Withdraw(account.Pin, 5000, account);
            }
            catch (InvalidPinException) { }
            catch (InSufficientFundsException) { }
            catch (AccountAlreadyClosedException) { }
        }

        public void Deposit()
        {
            //Collect Data from User
            IAccount account = AccountFactory.Create("Savings");
            account.Name = "Satish";
            account.Pin= 1234;
            account.Privilege = Privilege.GOLD;
            account.Isactive = true;
            account.Balance = 10000.00;

            //AccountManager manager = new AccountManager();
            IAccountManager manager = AccountManagerFactory.Create();
            try
            {
                manager.Deposit(4000, account);
            }
            catch (AccountAlreadyClosedException) { }
        }

        public void Transfer()
        {
            try
            {
                //Collect Data from User
                IAccount fromAccount = AccountFactory.Create("Savings");
                fromAccount.Name = "Rutuja";
                fromAccount.Balance = 100000;
                fromAccount.Pin = 1234;
                fromAccount.Privilege = Privilege.PREMIUM;
                fromAccount.Isactive = true;

                IAccount toAccount = AccountFactory.Create("Savings");
                toAccount.Name = "Satish";
                toAccount.Balance = 4000;
                toAccount.Pin = 1234;
                toAccount.Privilege = Privilege.GOLD;
                toAccount.Isactive = true;

                Transfer transferInfo = new Transfer();
                transferInfo.FromAccount = fromAccount;
                transferInfo.ToAccount = toAccount;
                transferInfo.PinNumber = 1234;
                transferInfo.Amount = 3000;
                transferInfo.TransferMode = TransferMode.IMPS;

                //AccountManager manager = new AccountManager();
                IAccountManager manager = AccountManagerFactory.Create();
                bool isTransferred = manager.Transfer(transferInfo);

                if (isTransferred)
                {
                    Console.WriteLine("Transfer is Successful");
                    Console.WriteLine("From Account Balance : " + fromAccount.Balance);
                    Console.WriteLine("From Account Balance : " + toAccount.Balance);
                }

                Console.Read();

            }
            catch (AccountAlreadyClosedException)
            {
                Console.WriteLine("Account Not Active");
            }
            catch (InSufficientFundsException)
            {
                Console.WriteLine("Insufficient Funds");
            }
            catch (InvalidPinException)
            {
                Console.WriteLine("Pin Number Invalid");
            }
        }
    }

}


