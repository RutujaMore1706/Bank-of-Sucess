﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Business;
using BOS1.Account.Entities;
using BOS1.Account.view;

namespace BOS1.Account
{
    class Program
    {
       
         static void Main(string[] args)
        {
            AccountForm form = new AccountForm();
            form.OpenAccount();
            form.CloseAccount();
            form.Deposit();
            form.Withdraw();
            form.Transfer();
            Console.Read();


        }

    }

}


/*
int i = 5;
SavingsAccount savingsAccount = new SavingsAccount();
savingsAccount.Name = "ABC";
savingsAccount.Gender = "Female";
savingsAccount.DateOfBirth = new DateTime(2000,10,12);
savingsAccount.PhoneNo = "12345896";
savingsAccount.Pin = 1234;
//Program to an Interface and Not to Implementation
//Expose Abstractions and Hide Implementations IAccount account = null; try


IAccount account = null;

try
{
    account = AccountFactory.Create("Savings");
    ISavingsAccount savings2 = (ISavingsAccount)account;
    savings2.Gender = "Male";
    try
    {
        if (savingsAccount.Open())
            Console.WriteLine("Account Opened");
        else
            Console.WriteLine("Account Not Opened");

        savingsAccount.Deposit(10000);
        Console.WriteLine("Deposited Successfully");

        savingsAccount.Withdraw(1234, 5000);
        Console.WriteLine("Withdrawn Successfully");

        IAccount fromAccount = AccountFactory.Create("Savings");
        fromAccount.Name = "Rutuja";
        fromAccount.Balance = 10000;
        fromAccount.Pin = 1234;
        fromAccount.Open();

        IAccount toAccount = AccountFactory.Create("Savings");
        toAccount.Name = "Satish";
        toAccount.Balance = 15000;
        toAccount.Pin = 1234;
        toAccount.Open();

        Transfer transferInfo = new Transfer();
        transferInfo.FromAccount = fromAccount;
        transferInfo.ToAccount = toAccount;
        transferInfo.PinNumber = 1234;
        transferInfo.Amount = 2000;
        transferInfo.TransferMode = TransferMode.IMPS;

        if(fromAccount.Transfer(transferInfo))
        {
            Console.WriteLine("Transfer successful");
            Console.WriteLine("From Account Balance: "+ fromAccount.Balance);
            Console.WriteLine("From Account Balance: " + toAccount.Balance);
        }
        Console.Read();

    }
    catch (AccountAlreadyClosedException ex)
    {
        Console.WriteLine("Account Not Active");
    }

    catch (InSufficientFundsException ex)
    {
        Console.WriteLine("Insufficient Funds");
    }
    catch (InvalidPinException ex)
    {
        Console.WriteLine("Pin Number Invalid");
    }
}

catch (InvalidAccountTypeException)
{ }
*/


//// program - Account Form - Account Manager - Account - Current
/// 
///  Account Form - Capture User info to pass to account manager                                                 - Saving
///  
/// Logic in Account manager
///  how to open account
///     check if it open already
///           yes? throw exception
///           no? 
///               check if type of acc -savings or current
///                   savings?  check age >18 (Downcasting DOB)
///                                  no?   throw InvalidAge Exception
///                                  yes? activate account - set activation date as today
///                                  
///                   current?   check registration number != null (downcast bcz account does not have that info) 
///                                      yes?  activate current account
///                                      no?  throw ecxeption
///               
///   