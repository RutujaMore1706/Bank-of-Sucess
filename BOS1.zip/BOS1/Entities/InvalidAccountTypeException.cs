﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;

namespace BOS1.Account
{
  
     class InvalidAccountTypeException :ApplicationException
    {
        public InvalidAccountTypeException()
        {
        }

        public InvalidAccountTypeException(string message) : base(message)
        {
        }

        public InvalidAccountTypeException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidAccountTypeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}