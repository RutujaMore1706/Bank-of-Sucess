﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Business;

namespace BOS1.Account.Entities
{
    class Transfer
    {
        public IAccount FromAccount { get; set; }
        public IAccount ToAccount { get; set; }
        public double Amount { get; set; }
        public int PinNumber { get; set; }
        public TransferMode TransferMode { get; set; }
    }

        enum TransferMode
        {
            IMPS =1,
            NEFT,
            RTGS
        }

       
   
}
