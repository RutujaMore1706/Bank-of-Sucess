﻿using Microsoft.OData.Edm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BOS1.Account.Business;
namespace BOS1.Account.Entities
{


     class SavingsAccount : Account, ISavingsAccount
    {
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string PhoneNo { get; set; }

    }
}




/*
public  bool Open()
{
    //throw new NotImplementedException();
    bool isOpen = false;
    try
    {
        if (CheckIfAgeIsValid(this.DateOfBirth))
            if (ActivateAccount())
                isOpen = true;
    }
    catch (AgeInvalidException ex)
    {
        throw ex;
    }
    catch (AccountAlreadyActiveException ex)
    {
        throw ex;
    }

    return isOpen;
}
public  bool Close()
{

    bool isClosed = false;
    try
    {
        if (Close())
            isClosed = true;
    }
    catch (AccountAlreadyClosedException ex)
    {
        throw ex; 
    }

    return isClosed;
}


/*
protected bool CloseAccount()
{
    //throw new NotImplementedException();
    bool isClosed = false;

    if (!this.Isactive)
        throw new AccountAlreadyClosedException("Account Already Closed");

    this.Isactive = false;
    this.DtClosed = DateTime.Now;

    return isClosed;
}
*/






