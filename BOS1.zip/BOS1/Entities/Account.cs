﻿using BOS1.Account.view;
using BOS1.Account.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOS1.Account.Entities
{

    class Account : IAccount
    {
        public int AccNo { get; set; } = IDGenerator.GenerateID();
        public string Name { get; set; }
        public int Pin { get; set; }
        public bool Isactive { get; set; }
        public DateTime DtOpening { get; set; }
        public DateTime DtClosed { get; set; }
        public double Balance { get; set; }

        public Privilege Privilege { get; set; }

        
        public bool Deposit(double amount)
        {
            throw new NotImplementedException();
        }

        public bool Withdraw(int pinNumber, double amount)
        {
            throw new NotImplementedException();
        }
        /*

abstract public bool Open();
public abstract bool Close();

public bool Deposit(double amount)
{
   bool isDeposited = false;

   //isactive
   if (!this.Isactive)
       throw new AccountAlreadyClosedException();
   try
   {
       ///valid pin
       if (DepositedIntoAccount(amount))
           isDeposited = true;

   }
   catch(System.Exception) { }


   return isDeposited;

}

public bool Withdraw(int pinNumber, double amount)
{
   bool isWithdrawn = false;

   //isactive
   if (!this.Isactive)
       throw new AccountAlreadyClosedException();
   try
   {
       ///Pin validity
       if (CheckPinValidity(pinNumber))
           if (CheckFundsInAccount(amount))
               if (WithdrawFromAcc(amount))
                   isWithdrawn = true;
   }
   catch (InvalidPinException ex)
   {

   }
   catch (InsufficientExecutionStackException ex)
   {

   }

   return isWithdrawn;

}
protected bool CheckPinValidity(int pinNumber)
{
   bool isValid = false;
   if (this.Pin == pinNumber)
   {
       isValid = true;
   }
   else
   {
       throw new InvalidPinException();
   }
   return isValid;
}
public bool CheckFundsInAccount(double amount)
{
   bool isAvailable = false;

   if (this.Balance >= amount)
       isAvailable = true;
   else
       throw new InSufficientFundsException();

   return isAvailable;
}
protected bool WithdrawFromAcc(double amount)
{
   bool isWithdrawn = false;
   this.Balance -= amount;
   isWithdrawn = true;


   return isWithdrawn;
}
protected bool DepositedIntoAccount(double amount)
{
   bool isDeposited = false;
   this.Balance += amount;
   isDeposited = true;

   return isDeposited;
}
public bool Transfer(Transfer transferInfo)
{
   bool isTransferred = false;
   //check if both active
   if (!(transferInfo.FromAccount.Isactive && transferInfo.ToAccount.Isactive))
   {
       throw new AccountAlreadyClosedException();

   }

   //check daily limit
   AccountPrivilegeManager privilegesManager = new AccountPrivilegeManager();
   double dailyLimit = privilegesManager.GetDailyLimit(transferInfo.FromAccount.Privilege);

   TransferLog log = new TransferLog();
   List<Transfer> transfers = null;
   double amountTransferred = 0.0;

   try
   {
       transfers = log.GetTransfers(transferInfo.FromAccount.AccNo);
   }
   catch (NoTransferAvailableException) { }

   // remaining amount 
   if (transfers != null)
   {
       foreach (Transfer transfer in transfers)
       {
           amountTransferred += transfer.Amount;
       }
   }
   // if limit exceeds
   bool isLimitExceeded = false;


   try
   {
       if (transferInfo.FromAccount.Withdraw(transferInfo.PinNumber, transferInfo.Amount))
       {
           if (transferInfo.ToAccount.Deposit(transferInfo.Amount))
           {
               isTransferred = true;
           }
       }
   }
   catch (AccountAlreadyClosedException)
   {
   }
   catch (InSufficientFundsException)
   { }
   catch (InvalidPinException)
   { }



   return isTransferred;
}

protected bool CheckIfLimitHasExceeded(double limit, double amountTransferred, double amountToBeTransferred)
{
   if ((amountToBeTransferred + amountTransferred) > limit)
       throw new DailyTransferLimitExceededException();

   return true;
}
*/
    }




}

