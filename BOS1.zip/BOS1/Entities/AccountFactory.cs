﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Business;
namespace BOS1.Account.Entities
{
    class AccountFactory
    {
        private AccountFactory()
        { }
        public static IAccount Create(string accountType)
        {
            IAccount account = null;
            if (accountType.Equals("Savings"))
                account = new SavingsAccount();
            else if (accountType.Equals("Current"))
                account = new CurrentAccount();
            else
                throw new InvalidAccountTypeException();
            return account;
        }
    }

}
