﻿using System;
using BOS1.Account.Business;
namespace BOS1.Account.Entities
{
     interface ICurrentAccount
    {
        string CompanyName { get; set; }
        string RegistrationNo { get; set; }
        string Website { get; set; }

      
    }
}