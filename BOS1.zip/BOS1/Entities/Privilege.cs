﻿using BOS1.Account.Business;
namespace BOS1.Account.Entities
{

         enum Privilege
        {
            PREMIUM =1,
            GOLD,
            SILVER
        }
}

