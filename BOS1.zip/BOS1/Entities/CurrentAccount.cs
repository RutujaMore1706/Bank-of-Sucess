﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BOS1.Account.Business;
namespace BOS1.Account.Entities
{
     class CurrentAccount : Account, ICurrentAccount
    {
        public string CompanyName { get; set; }
        public string Website { get; set; }
        public string RegistrationNo { get; set; }
    }

}


/*
public  bool Open()
{

    bool isOpened = false;

    try
    {
        if (CheckRegistrationNumberIsValid())
            if (ActivateAccount())
                isOpened = true;
    }
    catch (RegistrationNumberInvalidException )
    {

    }
    catch (AccountAlreadyActiveException )
    {

    }

    return isOpened;
}
/*
protected bool ActivateAccount()
{
    //throw new NotImplementedException();

    bool isActive = false;

    if (this.Isactive)
        throw new AccountAlreadyActiveException("Account Already Active");

    this.Isactive = true;
    this.DtOpening = DateTime.Now;

    return isActive;
}
*/
/*
protected bool CheckRegistrationNumberIsValid()
{
    bool isValid = false;
    if (this.RegistrationNo == null || this.RegistrationNo == " ")
    {
        throw new RegistrationNumberInvalidException("Company not Registered");

    }
    isValid = true;
    return isValid;
}

public  bool Close()
{

    bool isClosed = false;
    try
    {
        if (CloseAccount())
            isClosed = true;
    }
    catch (AccountAlreadyClosedException )
    {

    }

    return isClosed;
}

private bool CloseAccount()
{
    //throw new NotImplementedException();
    bool isClosed = false;

    if (!this.Isactive)
        throw new AccountAlreadyClosedException("Account Already Closed");

    this.Isactive = false;
    this.DtClosed = DateTime.Now;

    return isClosed;
}
*/
