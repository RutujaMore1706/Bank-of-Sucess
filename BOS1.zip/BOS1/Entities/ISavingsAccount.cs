﻿using System;
using BOS1.Account.Business;
namespace BOS1.Account.Entities
{
     interface ISavingsAccount
    {
        DateTime DateOfBirth { get; set; }
        string Gender { get; set; }
        string PhoneNo { get; set; }
        
    }
}