﻿using System;
using BOS1.Account.Business;
namespace BOS1.Account.Entities
{
    interface IAccount
    {
        int AccNo { get; set; }
        double Balance { get; set; }
        DateTime DtClosed { get; set; }
        DateTime DtOpening { get; set; }
        bool Isactive { get; set; }
        string Name { get; set; }
        int Pin { get; set; }
        Privilege Privilege { get; set; }

       /*
        bool Close();       
        bool Open();        
        bool Withdraw(int pinNumber, double amount);
        bool Deposit(double amount);        
        bool Transfer(Transfer trasferInfo);


        */
    
    }
}