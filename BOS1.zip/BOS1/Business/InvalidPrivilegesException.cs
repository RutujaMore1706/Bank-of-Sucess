﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    
    internal class InvalidPrivilegesException : System.Exception
    {
        public InvalidPrivilegesException()
        {
        }

        public InvalidPrivilegesException(string message) : base(message)
        {
        }

        public InvalidPrivilegesException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidPrivilegesException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}