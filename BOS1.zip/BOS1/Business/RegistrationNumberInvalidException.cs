﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    [Serializable]
    internal class RegistrationNumberInvalidException : System.Exception
    {
        public RegistrationNumberInvalidException()
        {
        }

        public RegistrationNumberInvalidException(string message) : base(message)
        {
        }

        public RegistrationNumberInvalidException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected RegistrationNumberInvalidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}