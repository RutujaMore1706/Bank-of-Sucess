﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BOS1.Account.Business
{
    class AccountAlreadyClosedException : ApplicationException
    {
        public AccountAlreadyClosedException()
        {

        }
        public AccountAlreadyClosedException(string message) : base(message)
        {

        }

        public AccountAlreadyClosedException(string message, Exception exception) : base(message, exception)
        {

        }
    }

}
