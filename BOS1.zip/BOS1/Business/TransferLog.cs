﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;
using BOS1.Account.view;
namespace BOS1.Account.Business
{
    class TransferLog
    {
        protected Dictionary<long, List<Transfer>> Transfers { get; set; }

        public TransferLog()
        {
            Transfers = new Dictionary<long, List<Transfer>>();
        }
        public void LogTransfer(Transfer transferInfo)
        {
            if (Transfers.ContainsKey(transferInfo.FromAccount.AccNo))
            {
                // transfers already performed 
               
                Transfers[transferInfo.FromAccount.AccNo].Add(transferInfo);
             }
            else
            {
                //no transfer 
                List<Transfer> transfers = new List<Transfer>();
                 transfers.Add(transferInfo);

                Transfers.Add(transferInfo.FromAccount.AccNo, transfers);
            }
        }

        public List<Transfer> GetTransfers(long accountNumber)
            {
                 //list of transfers
                List<Transfer> transfers = null;

                if (Transfers.ContainsKey(accountNumber))
                    transfers = Transfers[accountNumber];
                else
                    throw new NoTransferAvailableException();

                return transfers;
            }
    }
}



  
