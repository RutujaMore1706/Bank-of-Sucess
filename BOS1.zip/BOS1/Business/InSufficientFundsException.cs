﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;
namespace BOS1.Account.Business
{
    
    internal class InSufficientFundsException : System.Exception
    {
        public InSufficientFundsException()
        {
        }

        public InSufficientFundsException(string message) : base(message)
        {
        }

        public InSufficientFundsException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected InSufficientFundsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}