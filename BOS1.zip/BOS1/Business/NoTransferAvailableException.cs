﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;
namespace BOS1.Account.Business
{
   
    internal class NoTransferAvailableException : System.Exception
    {
        public NoTransferAvailableException()
        {
        }

        public NoTransferAvailableException(string message) : base(message)
        {
        }

        public NoTransferAvailableException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected NoTransferAvailableException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}