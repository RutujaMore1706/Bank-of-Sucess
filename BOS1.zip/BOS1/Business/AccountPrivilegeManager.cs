﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;


namespace BOS1.Account.Business
{
    class AccountPrivilegeManager
    {
        /*
        public double PREMIUM { get; set; }
        public double GOLG { get; set; }
        public double SILVER { get; set; }
        */

        protected Dictionary<Privilege, Double> DailyLimits { get; set; }

        public AccountPrivilegeManager()
        {
            DailyLimits = new Dictionary<Privilege,double>();

            DailyLimits.Add(Privilege.PREMIUM, 100000);
            DailyLimits.Add(Privilege.GOLD, 50000);
            DailyLimits.Add(Privilege.SILVER, 20000);


        }
        public double GetDailyLimit(Privilege privilege)
        {
            if (!DailyLimits.ContainsKey(privilege))
                throw new InvalidPrivilegesException();

            return DailyLimits[privilege];
        }

            
            
    }
}
