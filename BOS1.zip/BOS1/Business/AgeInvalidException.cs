﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    class AgeInvalidException : ApplicationException

    {
        public AgeInvalidException()
        {
            
        }
        public AgeInvalidException(string message):base(message)
        {

        }
        public AgeInvalidException(string message, Exception exception) : base(message, exception)
        {

        }


    }
}
