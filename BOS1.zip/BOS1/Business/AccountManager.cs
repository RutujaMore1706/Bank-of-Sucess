﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    class AccountManager : IAccountManager
    {
        public bool Open(IAccount account, string accountType)
        {
            bool isOpened = false;

            //check for already open account
            if (account.Isactive)
                throw new AccountAlreadyActiveException();

            try
            {
                if (accountType.Equals("Savings"))
                {
                    ISavingsAccount savings = (ISavingsAccount)account;
                    if (CheckIfAgeIsValid(savings.DateOfBirth))
                        isOpened = ActivateAccount(account);

                }
                else if (accountType.Equals("Current"))
                {
                    ICurrentAccount current = (ICurrentAccount)account;
                    if (CheckRegistrationNumberIsValid(current))
                        isOpened = ActivateAccount(account);
                }

            }
            catch(AgeInvalidException ex)
            {
                throw ex;
            }
            catch (RegistrationNumberInvalidException ex) { throw ex; }
                       
            return isOpened;
        }
        protected bool CheckIfAgeIsValid(DateTime DateOfBirth)
        {
            bool isValid = false;
            if ((DateTime.Now.Year - DateOfBirth.Year) > 18)
                isValid = true;
            else
                throw new AgeInvalidException("Age is Invalid");
            return isValid;
        }

        protected bool CheckRegistrationNumberIsValid(ICurrentAccount current)
        {
            bool isValid = false;
            //ICurrentAccount  CurrentAccount = (ICurrentAccount)account;
            if (current.RegistrationNo == null || current.RegistrationNo == " ")
            {
                throw new RegistrationNumberInvalidException("Company not Registered");

            }
            isValid = true;
            return isValid;
        }

        protected bool ActivateAccount(IAccount account)
        {
            //throw new NotImplementedException();

            bool isActive = false;

            if (account.Isactive)
                throw new AccountAlreadyActiveException("Account Already Active");

            account.Isactive = true;
            account.DtOpening = DateTime.Now;

            return isActive;
        }
        public bool Close(IAccount account)
        {
            bool isClosed = false;
            /* if (accountType.Equals("Savings"))
            {
                ISavingsAccount savings = (ISavingsAccount)account;
                isClosed = savings.Open();
            }
            else if (accountType.Equals("Current"))
            {
                ICurrentAccount current = (ICurrentAccount)account;
                isClosed = current.Open();
            }
            */

            if(!account.Isactive)
                throw new AccountAlreadyClosedException("Account Already Closed");

            account.Isactive = false;
            account.DtClosed = DateTime.Now;
            return isClosed;
        }

        public bool Withdraw(int pinNumber, double amount, IAccount account)
        {
            //Initialization
            bool isWithdrawn = false;

            //Account active?
            /*
            if (!account.Isactive)
                throw new AccountAlreadyClosedException();
            */

            try
            {
                if (CheckIfPinNumberIsValid(pinNumber, account))
                    if (CheckFundsInAccount(amount, account))
                        if (WithdrawFromAccount(amount, account))
                            isWithdrawn = true;
            }
            catch (InvalidPinException )
            {
                //throw ex;
            }
            catch (InsufficientExecutionStackException )
            {
                //throw ex;
            }

            //Return
            return isWithdrawn;
        }

        protected bool CheckIfPinNumberIsValid(int pinNumber, IAccount account)
        {
            bool isValid = false;

            if (account.Pin == pinNumber)
                isValid = true;
            else
                throw new InvalidPinException();

            return isValid;
        }

        protected bool CheckFundsInAccount(double amount, IAccount account)
        {
            // Check if funds are available in the account
            bool isAvailable = false;

            //Check if balance in account is more than the given amount
            if (account.Balance >= amount)
                isAvailable = true;
            else
                throw new InSufficientFundsException();

            return isAvailable;
        }

        protected bool WithdrawFromAccount(double amount, IAccount account)
        {
            bool isWithdrawn = false;

            account.Balance -= amount;
            isWithdrawn = true;

            return isWithdrawn;
        }

        public bool Deposit(double amount, IAccount account)
        {
            //Initialization
            bool isDeposited = false;

            //Account should be active00
            /*
            if (!account.Isactive)
                throw new AccountAlreadyClosedException();
            */

            try
            {
                if (DepositIntoAccount(amount, account))
                    isDeposited = true;
            }
            catch (Exception) { }

            //Return
            return isDeposited;
        }

        protected bool DepositIntoAccount(double amount, IAccount account)
        {
            bool isDeposited = false;

            account.Balance += amount;
            isDeposited = true;

            return isDeposited;
        }

        public bool Transfer(Transfer transferInfo)
        {
            bool isTransferred = false;

            //Check if active
            if (!(transferInfo.FromAccount.Isactive && transferInfo.ToAccount.Isactive))
                throw new AccountAlreadyClosedException();

            //Check the Daily Limit 
            // Limit for the Privilege 
            AccountPrivilegeManager privilegeManager = new AccountPrivilegeManager();
            double dailyLimit = privilegeManager.GetDailyLimit(transferInfo.FromAccount.Privilege);

            // Transfers for the day
            TransferLog log = new TransferLog();
            List<Transfer> transfers = null;
            double amountTransferred = 0.0;

            try
            {
                transfers = log.GetTransfers(transferInfo.FromAccount.AccNo);
            }
            catch (NoTransferAvailableException) { }

            // remaining amount that can be transferred
            if (transfers != null)
            {
                foreach (Transfer transfer in transfers)
                {
                    amountTransferred += transfer.Amount;
                }
            }
            //4. Throw exception if limit has exceeded
            bool isLimitExceeded = false;

            try
            {
                isLimitExceeded = CheckIfLimitHasExceeded(dailyLimit, amountTransferred, transferInfo.Amount);

                //Withdraw from the account - (From Account)
                if (this.Withdraw(transferInfo.PinNumber, transferInfo.Amount, transferInfo.FromAccount))
                    //Deposit into accout - (To Account)
                    if (this.Deposit(transferInfo.Amount, transferInfo.ToAccount))
                        isTransferred = true;

                //6. Log the transfer transaction
                log.LogTransfer(transferInfo);

            }
            catch (DailyTransferLimitExceededException e)
            {
                throw e;
            }
            catch (AccountAlreadyClosedException e) { throw e; }
            catch (InSufficientFundsException e) { throw e; }
            catch (InvalidPinException e) { throw e; }

            return isTransferred;
        }

        protected bool CheckIfLimitHasExceeded(double limit, double amountTransferred, double amountToBeTransferred)
        {
            if ((amountToBeTransferred + amountTransferred) > limit)
                throw new DailyTransferLimitExceededException();

            return true;
        }

    }
}
