﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;
namespace BOS1.Account.Business
{
    interface IAccountManager
    {
        bool Open(IAccount account, string accountType);



        bool Close(IAccount account);



        bool Withdraw(int pinNumber, double amount, IAccount account);



        bool Deposit(double amount, IAccount account);



        bool Transfer(Transfer transferInfo);


    }
}
