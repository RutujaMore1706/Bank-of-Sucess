﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;
namespace BOS1.Account.Business
{
     class AccountManagerFactory
        {
            public static IAccountManager Create()
            {
                return new AccountManager();
            }
        }
    }
