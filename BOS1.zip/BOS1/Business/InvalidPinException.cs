﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    
    internal class InvalidPinException : System.Exception
    {
        public InvalidPinException()
        {
        }

        public InvalidPinException(string message) : base(message)
        {
        }

        public InvalidPinException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidPinException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}