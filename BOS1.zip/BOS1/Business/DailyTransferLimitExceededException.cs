﻿using System;
using System.Runtime.Serialization;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    
    internal class DailyTransferLimitExceededException : System.Exception
    {
        public DailyTransferLimitExceededException()
        {
        }

        public DailyTransferLimitExceededException(string message) : base(message)
        {
        }

        public DailyTransferLimitExceededException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected DailyTransferLimitExceededException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}