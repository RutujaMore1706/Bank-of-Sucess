﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOS1.Account.Entities;

namespace BOS1.Account.Business
{
    class AccountAlreadyActiveException : ApplicationException
    {
        public AccountAlreadyActiveException()
        {

        }
        public AccountAlreadyActiveException(string message) : base(message)
        {

        }

        public AccountAlreadyActiveException(string message, Exception exception) : base(message, exception)
        {

        }
    }
}
