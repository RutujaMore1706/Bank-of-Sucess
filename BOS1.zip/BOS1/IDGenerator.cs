﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace BOS1.Account
{
    public class IDGenerator
    {
        public static int GenerateID()
        {
            //get the number from txt file
            StreamReader reader = null;
            StreamWriter writer = null;
            int number;
            try
            {
                reader = new StreamReader("Number.txt");
                number = int.Parse(reader.ReadLine());
                reader.Close();
                writer = new StreamWriter("Number.txt");
                writer.WriteLine(++number);

               
            }
            finally 
            {

                reader.Close();
                writer.Close();
            }
            return number;
        }
    }
}